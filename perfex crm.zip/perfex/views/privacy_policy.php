<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="panel_s">
    <div class="panel-body">
        <h4 class="privacy-policy-heading"><?php echo _l('privacy_policy'); ?></h4>
        <hr />
        <div class="tc-content privacy-policy">
            <?php echo $policy; ?>
        </div>
    </div>
</div>
